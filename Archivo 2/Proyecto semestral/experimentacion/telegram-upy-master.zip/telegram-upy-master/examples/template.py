#REMEMBER TO RENAME FILE TO main.py BEFORE UPLOAING TO THE BOARD
from utelegram import Bot

TOKEN = 'YourTokenGoesHere'
bot = Bot(TOKEN)

bot.loop()
